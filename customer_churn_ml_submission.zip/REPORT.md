# Customer Churn Prediction — Project Report

## 1. Objective
Build and evaluate supervised classification models that estimate whether a customer will churn (`Churn = Yes`).

## 2. Dataset overview
- Records: **800**
- Features available before target removal: **12**
- Target: `Churn` (Yes = 1, No = 0)
- Class distribution: **466 No Churn (58.2%)** and **334 Churn (41.8%)**
- No missing values were found in the supplied file.
- `CustomerID` was excluded from model features because it is an identifier, not a meaningful predictive measurement.

## 3. Preprocessing
- Numeric columns: median imputation followed by MinMax scaling.
- Categorical columns: most-frequent imputation followed by One-Hot Encoding.
- Preprocessing is placed inside an sklearn `Pipeline` and `ColumnTransformer`, so transformations are fitted on training data only and applied consistently to the test data.
- Unknown categories are safely ignored during inference.

## 4. Train-test split
An 80/20 split was used with `random_state=42` and stratification on the target. This gives a reproducible holdout evaluation while preserving the churn/non-churn proportions.

## 5. Models
- Logistic Regression (`class_weight="balanced"`)
- Random Forest (400 trees, `min_samples_leaf=2`, `class_weight="balanced"`)

## 6. Evaluation results
| Model               |   Accuracy |   Precision |   Recall |   F1-score |   ROC-AUC |
|:--------------------|-----------:|------------:|---------:|-----------:|----------:|
| Logistic Regression |      0.669 |       0.583 |    0.731 |      0.649 |     0.681 |
| Random Forest       |      0.637 |       0.562 |    0.612 |      0.586 |     0.673 |

Precision measures how many predicted churners actually churned; recall measures how many actual churners were detected; F1 is the harmonic mean of precision and recall; ROC-AUC measures ranking ability across classification thresholds.

**Selected model: Logistic Regression**, because it achieved the higher holdout ROC-AUC (0.681) and also higher precision, recall, and F1-score in this run.

## 7. Visual outputs
- `outputs/confusion_matrix.png`
- `outputs/roc_curves.png`
- `outputs/classification_report.txt`

## 8. Customer risk score export
`outputs/customer_churn_risk_predictions.csv` contains one row per customer, the actual churn label, predicted churn probability, and a Low/Medium/High risk band. The selected pipeline is refitted on the full dataset before generating these descriptive scores.

## 9. Conclusion and limitations
On this holdout split, Logistic Regression performed better than Random Forest across the reported metrics. The best ROC-AUC is about 0.681, which indicates moderate ranking performance rather than a highly reliable production predictor. Results are based on a synthetic dataset and a single random train/test split; they should not be interpreted as proof of real-world performance. Before deployment, validate on newer unseen customer data, check calibration and subgroup performance, and choose a risk threshold based on business costs.

## 10. Reproducibility
Run `pip install -r requirements.txt`, then `python train_model.py` from the project directory. All model outputs are recreated in the `outputs/` folder.
