# Customer Churn Prediction

Reproducible scikit-learn classification project for the Workora assignment.

## Run
```bash
pip install -r requirements.txt
python train_model.py
```

The script performs preprocessing (One-Hot Encoding + MinMax scaling), an 80/20 stratified train-test split, Logistic Regression and Random Forest training, evaluation, plots, and churn-risk export.

## Files
- `customer_churn_model_v2.csv` — supplied dataset
- `train_model.py` — end-to-end reproducible pipeline
- `REPORT.md` — project report and measured test metrics
- `outputs/model_comparison.csv` — model metrics
- `outputs/classification_report.txt` — detailed report for selected model
- `outputs/confusion_matrix.png`, `outputs/roc_curves.png` — evaluation plots
- `outputs/customer_churn_risk_predictions.csv` — per-customer churn risk scores

## Publish to satisfy the submission proof
1. Create a GitHub repository (public if the evaluator needs to open it).
2. Upload all files in this folder, including the `outputs/` folder.
3. Copy the repository URL and submit it in Workora.
4. Alternatively, upload the project files to Google Colab, run `train_model.py` (or convert it into notebook cells), and share the Colab link with viewer access.

**Important:** I prepared the code and artifacts, but I cannot publish to your GitHub/Colab account or generate an authenticated public URL from this chat. You must complete the upload/sign-in step and submit the resulting link.
