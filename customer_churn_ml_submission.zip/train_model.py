"""
Customer Churn Prediction - reproducible ML pipeline
Run: python train_model.py
"""
import os
import pandas as pd
import matplotlib.pyplot as plt
from sklearn.model_selection import train_test_split
from sklearn.compose import ColumnTransformer
from sklearn.preprocessing import OneHotEncoder, MinMaxScaler
from sklearn.pipeline import Pipeline
from sklearn.impute import SimpleImputer
from sklearn.linear_model import LogisticRegression
from sklearn.ensemble import RandomForestClassifier
from sklearn.metrics import (accuracy_score, precision_score, recall_score, f1_score,
                             roc_auc_score, classification_report, confusion_matrix,
                             ConfusionMatrixDisplay, RocCurveDisplay)

DATA_PATH = "customer_churn_model_v2.csv"
OUT = "outputs"
os.makedirs(OUT, exist_ok=True)

df = pd.read_csv(DATA_PATH)
target = "Churn"
X = df.drop(columns=[target, "CustomerID"], errors="ignore")
y = df[target].astype(str).str.strip().str.title().map({"No": 0, "Yes": 1})
if y.isna().any():
    raise ValueError("Unexpected target values in Churn column.")

numeric_features = X.select_dtypes(include=["number"]).columns.tolist()
categorical_features = X.select_dtypes(exclude=["number"]).columns.tolist()

preprocessor = ColumnTransformer([
    ("numeric", Pipeline([
        ("imputer", SimpleImputer(strategy="median")),
        ("scaler", MinMaxScaler())
    ]), numeric_features),
    ("categorical", Pipeline([
        ("imputer", SimpleImputer(strategy="most_frequent")),
        ("onehot", OneHotEncoder(handle_unknown="ignore"))
    ]), categorical_features)
])

X_train, X_test, y_train, y_test = train_test_split(
    X, y, test_size=0.20, random_state=42, stratify=y
)

candidates = {
    "Logistic Regression": LogisticRegression(
        max_iter=2000, class_weight="balanced", random_state=42
    ),
    "Random Forest": RandomForestClassifier(
        n_estimators=400, min_samples_leaf=2, class_weight="balanced",
        random_state=42, n_jobs=-1
    )
}

rows = []
fitted = {}
for name, estimator in candidates.items():
    model = Pipeline([("preprocess", preprocessor), ("classifier", estimator)])
    model.fit(X_train, y_train)
    predicted = model.predict(X_test)
    probabilities = model.predict_proba(X_test)[:, 1]
    rows.append({
        "Model": name,
        "Accuracy": accuracy_score(y_test, predicted),
        "Precision": precision_score(y_test, predicted, zero_division=0),
        "Recall": recall_score(y_test, predicted, zero_division=0),
        "F1-score": f1_score(y_test, predicted, zero_division=0),
        "ROC-AUC": roc_auc_score(y_test, probabilities)
    })
    fitted[name] = model

comparison = pd.DataFrame(rows).sort_values("ROC-AUC", ascending=False)
comparison.to_csv(os.path.join(OUT, "model_comparison.csv"), index=False)

# Select the model with the highest test ROC-AUC, using the same holdout set.
best_name = comparison.iloc[0]["Model"]
best_model = fitted[best_name]
best_pred = best_model.predict(X_test)
best_prob = best_model.predict_proba(X_test)[:, 1]

report = classification_report(y_test, best_pred, target_names=["No Churn", "Churn"], zero_division=0)
with open(os.path.join(OUT, "classification_report.txt"), "w") as f:
    f.write(f"Selected model: {best_name}\n\n{report}\n")
    f.write(f"ROC-AUC: {roc_auc_score(y_test, best_prob):.4f}\n")

fig, ax = plt.subplots(figsize=(6, 5))
ConfusionMatrixDisplay.from_predictions(
    y_test, best_pred, display_labels=["No Churn", "Churn"], cmap="Blues", ax=ax
)
ax.set_title(f"Confusion Matrix - {best_name}")
fig.tight_layout()
fig.savefig(os.path.join(OUT, "confusion_matrix.png"), dpi=160)
plt.close(fig)

fig, ax = plt.subplots(figsize=(6, 5))
for name, model in fitted.items():
    RocCurveDisplay.from_estimator(model, X_test, y_test, name=name, ax=ax)
ax.set_title("ROC Curves - Customer Churn")
fig.tight_layout()
fig.savefig(os.path.join(OUT, "roc_curves.png"), dpi=160)
plt.close(fig)

# Refit selected pipeline on all available rows for final customer risk scoring.
best_model.fit(X, y)
all_prob = best_model.predict_proba(X)[:, 1]
predictions = pd.DataFrame({
    "CustomerID": df["CustomerID"] if "CustomerID" in df.columns else range(1, len(df)+1),
    "ActualChurn": df[target],
    "PredictedChurnRisk": all_prob,
    "RiskBand": pd.cut(all_prob, bins=[-0.001, 0.33, 0.66, 1.001],
                       labels=["Low", "Medium", "High"])
})
predictions.to_csv(os.path.join(OUT, "customer_churn_risk_predictions.csv"), index=False)

print("Model comparison:")
print(comparison.to_string(index=False))
print(f"\nSelected model: {best_name}")
print(f"Outputs saved in ./{OUT}/")
